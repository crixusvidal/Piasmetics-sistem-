@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Necesitas instalar Node.js desde https://nodejs.org y volver a abrir este archivo. & pause & exit /b 1)
node servidor-local.cjs app 3000
pause
